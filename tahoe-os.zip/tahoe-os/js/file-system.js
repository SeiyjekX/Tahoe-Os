const FileSystem = {
    defaultFS: {
        "/": { type: "dir", children: ["home", "etc", "bin"] },
        "/home": { type: "dir", children: ["root"] },
        "/home/root": { type: "dir", children: ["welcome.txt", "notes.md"] },
        "/home/root/welcome.txt": { type: "file", content: "TAHOE OS v2.0.26\nRunning on MSI GF63 Thin 10UC.\nStatus: System Optimal." },
        "/home/root/notes.md": { type: "file", content: "# TODO\n- Setup Network\n- Exploit target server\n- Save session" }
    },
    init() {
        if (!localStorage.getItem('tahoe_fs')) {
            localStorage.setItem('tahoe_fs', JSON.stringify(this.defaultFS));
        }
    },
    getFS: () => JSON.parse(localStorage.getItem('tahoe_fs')),
    saveFS: (fs) => localStorage.setItem('tahoe_fs', JSON.stringify(fs)),
    ls() {
        const fs = this.getFS();
        return fs["/home/root"].children.join("  ");
    }
};
FileSystem.init();