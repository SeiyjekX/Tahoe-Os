// js/kernel.js
document.getElementById('boot-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const osChoice = document.getElementById('os-choice').value;
    const statusLog = document.getElementById('status-log');
    
    // 1. เก็บข้อมูลลง LocalStorage (เพื่อให้หน้า Desktop ดึงไปใช้ต่อได้)
    const session = {
        os: osChoice,
        bootTime: new Date().toISOString(),
        isOnline: true
    };
    localStorage.setItem('tahoe_session', JSON.stringify(session));

    // 2. แสดงสถานะการบูต (Visual Effect)
    statusLog.classList.remove('hidden');
    document.querySelector('button').disabled = true;
    document.querySelector('button').innerText = "BOOTING...";

    // 3. เปลี่ยนหน้าไปโฟลเดอร์ /desktop/ (URL จะออกมาคลีนๆ)
    setTimeout(() => {
        window.location.href = './desktop/'; 
    }, 2500);
});