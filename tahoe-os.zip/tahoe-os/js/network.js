const NetworkSystem = {
    generateIP() {
        let session = JSON.parse(localStorage.getItem('tahoe_session')) || {};
        if (!session.ip) {
            const subnet = Math.floor(Math.random() * 254) + 1;
            const host = Math.floor(Math.random() * 254) + 1;
            session.ip = `192.168.${subnet}.${host}`;
            localStorage.setItem('tahoe_session', JSON.stringify(session));
        }
        return session.ip;
    },
    
    // จำลองการดึงข้อมูลแบบมี Delay (3D Interaction Feel)
    async getScanResults() {
        console.log("Network: Scanning targets...");
        return [
            "192.168.1.1   [UP]   Gateway (MSI-Router)",
            "192.168.1.105 [UP]   Localhost (Your MSI GF63)",
            "192.168.1.220 [UP]   Target-Database-Server",
            "172.16.0.42   [UP]   Unknown-IoT-Camera",
            `STATUS: ${this.generateIP()} IS ACTIVE`
        ].join("\n");
    }
};