
const appConfig = {
    kali: [{ id: 'terminal', name: 'Terminal', icon: '🐚' }, { id: 'settings', name: 'Settings', icon: '⚙️' }],
    win11: [{ id: 'browser', name: 'Edge', icon: '🌐' }, { id: 'settings', name: 'Settings', icon: '⚙️' }],
    macos: [{ id: 'safari', name: 'Safari', icon: '🧭' }, { id: 'settings', name: 'Settings', icon: '⚙️' }]
};

const cssWallpapers = {
    cyber_bot: 'radial-gradient(circle at 50% 40%, #111 0%, #000 100%)',
    carbon_red: 'linear-gradient(45deg, #111 25%, #222 25%, #222 50%, #111 50%, #111 75%, #222 75%, #222 100%)'
};

let topZIndex = 1000;
let runningApps = [];

document.addEventListener('DOMContentLoaded', () => {
    const session = JSON.parse(localStorage.getItem('tahoe_session')) || { os: 'win11' };
    renderOS(session.os);
    startTime();
});

// --- ระบบแยกประเภทแอป ---
function getAppContent(app) {
    if (app.id === 'terminal') {
        return `<div class="bg-black text-green-500 font-mono p-4 h-full text-sm">root@tahoe:~# <span class="animate-pulse">_</span></div>`;
    } else if (app.id === 'settings') {
        return `
            <div class="p-8 text-white bg-[#0a0a0a] h-full">
                <h3 class="text-xl font-bold mb-4 italic tracking-tighter">APPEARANCE</h3>
                <div class="space-y-4">
                    <div class="bg-zinc-900 p-4 rounded-xl border border-white/5">
                        <label class="text-[10px] uppercase opacity-40">Custom Wallpaper URL</label>
                        <input type="text" id="wall-url" class="w-full bg-black mt-2 p-2 rounded border border-white/10 text-xs">
                        <button onclick="setCustomUrlWallpaper(document.getElementById('wall-url').value)" class="mt-3 bg-blue-600 px-4 py-2 rounded text-[10px] font-black uppercase">Apply</button>
                    </div>
                </div>
            </div>`;
    }
    return `<iframe src="https://www.google.com/search?igu=1" class="w-full h-full border-none bg-white"></iframe>`;
}

// --- Window Controller (Maximize/Minimize/Close) ---
window.maximizeWindow = function(appId) {
    const app = runningApps.find(a => a.id === appId);
    if (!app) return;
    const win = app.element;
    if (!app.isMaximized) {
        app.oldBounds = { t: win.style.top, l: win.style.left, w: win.style.width, h: win.style.height };
        Object.assign(win.style, { top: '0', left: '0', width: '100vw', height: 'calc(100vh - 84px)', borderRadius: '0' });
        app.isMaximized = true;
    } else {
        Object.assign(win.style, { top: app.oldBounds.t, left: app.oldBounds.l, width: app.oldBounds.w, height: app.oldBounds.h, borderRadius: '16px' });
        app.isMaximized = false;
    }
};

window.closeApp = (id) => {
    document.getElementById(`win-${id}`)?.remove();
    runningApps = runningApps.filter(a => a.id !== id);
};

window.launchApp = function(app) {
    if (document.getElementById(`win-${app.id}`)) {
        const existing = document.getElementById(`win-${app.id}`);
        existing.style.display = 'flex';
        existing.style.zIndex = ++topZIndex;
        return;
    }

    const os = JSON.parse(localStorage.getItem('tahoe_session')).os;
    const win = document.createElement('div');
    win.id = `win-${app.id}`;
    win.className = "window absolute flex flex-col pointer-events-auto";
    win.style.cssText = `width:850px; height:550px; top:80px; left:200px; z-index:${++topZIndex};`;

    win.innerHTML = `
        <div class="window-header">${createHeader(os, app)}</div>
        <div class="window-body">${getAppContent(app)}</div>
        <div class="resizer" onmousedown="initResize(event)" style="width:15px; height:15px; position:absolute; bottom:0; right:0; cursor:nwse-resize; z-index:100;"></div>`;

    document.getElementById('window-layer').appendChild(win);
    runningApps.push({ id: app.id, element: win, os: os, isMaximized: false });
    makeDraggable(win);
};

function createHeader(os, app) {
    if (os === 'macos') {
        return `
            <div class="flex gap-2 ml-4">
                <div onclick="closeApp('${app.id}')" class="btn-mac bg-[#ff5f57]"></div>
                <div onclick="maximizeWindow('${app.id}')" class="btn-mac bg-[#febc2e]"></div>
                <div onclick="maximizeWindow('${app.id}')" class="btn-mac bg-[#28c841]"></div>
            </div>
            <div class="flex-1 text-center text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">${app.name}</div>
            <div class="w-20"></div>`;
    } else {
        return `
            <div class="ml-4 text-[10px] font-black text-white/40 uppercase tracking-widest">${app.name}</div>
            <div class="flex h-full ml-auto">
                <div onclick="maximizeWindow('${app.id}')" class="btn-win">▢</div>
                <div onclick="closeApp('${app.id}')" class="btn-win hover:bg-red-600">✕</div>
            </div>`;
    }
}

// --- Taskbar Engine ---
function updateTaskbar(os) {
    const bar = document.getElementById('taskbar');
    if (!bar) return;
    bar.className = "floating-dock";
    
    let html = `<div class="text-2xl drop-shadow-lg">${os === 'win11' ? '🏁' : os === 'macos' ? '🍎' : '💀'}</div>`;
    appConfig[os].forEach(app => {
        html += `<div onclick='launchApp(${JSON.stringify(app)})' class="text-3xl cursor-pointer hover:-translate-y-2 transition-transform drop-shadow-xl">${app.icon}</div>`;
    });
    html += `<div id="system-tray" class="ml-4 pl-6 border-l border-white/10 text-[11px] font-black text-white/40">00:00</div>`;
    bar.innerHTML = html;
}

function renderOS(os) {
    const settings = JSON.parse(localStorage.getItem(`tahoe_settings_${os}`)) || { isCustomUrl: false };
    applySettings(settings, os);
    updateTaskbar(os);
    
    const grid = document.getElementById('app-grid');
    grid.innerHTML = '';
    appConfig[os].forEach(app => {
        const div = document.createElement('div');
        div.className = "flex flex-col items-center cursor-pointer p-4 hover:bg-white/5 rounded-2xl group w-24 transition";
        div.onclick = () => launchApp(app);
        div.innerHTML = `<div class="text-5xl group-hover:scale-110 transition drop-shadow-2xl">${app.icon}</div><span class="text-[9px] mt-2 text-white/50 font-bold uppercase">${app.name}</span>`;
        grid.appendChild(div);
    });
}

function applySettings(settings, os) {
    const scene = document.getElementById('desktop-scene');
    const oldChar = document.getElementById('css-character');
    if (oldChar) oldChar.remove();

    if (settings.isCustomUrl) {
        scene.style.background = `url('${settings.wallpaper}') center/cover no-repeat`;
    } else {
        scene.style.background = settings.wallpaper || cssWallpapers.cyber_bot;
        const char = document.createElement('div');
        char.id = 'css-character';
        char.className = 'absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-10 pointer-events-none text-[150px] text-white';
        char.innerHTML = os === 'kali' ? '💀' : '[ • ◡ • ]';
        scene.appendChild(char);
    }
}

function makeDraggable(el) {
    const header = el.querySelector('.window-header');
    header.onmousedown = (e) => {
        if (e.target.closest('.btn-mac') || e.target.closest('.btn-win')) return;
        const startX = e.clientX - el.offsetLeft;
        const startY = e.clientY - el.offsetTop;
        const move = (m) => {
            el.style.left = (m.clientX - startX) + "px";
            el.style.top = (m.clientY - startY) + "px";
            el.style.transform = "rotateX(1deg) rotateY(1deg) scale(1.01)";
        };
        const up = () => { el.style.transform = "none"; document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', up); };
        document.addEventListener('mousemove', move);
        document.addEventListener('mouseup', up);
    };
}

function startTime() {
    setInterval(() => {
        const tray = document.getElementById('system-tray');
        if (tray) tray.innerHTML = new Date().toLocaleTimeString('th-TH', {hour:'2-digit', minute:'2-digit'});
    }, 1000);
}