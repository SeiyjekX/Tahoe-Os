const TerminalCore = {
    commands: {
        "help": () => "Available Commands:\n- register [u] [p] : Create account\n- login [u] [p]    : Access system & get IP\n- ls               : List files\n- cat [file]       : Read file content\n- nano [file]      : Open text editor\n- ifconfig         : Network configuration\n- nmap             : Network scan\n- clear            : Clear screen\n- whoami           : Current user",
        
        "register": (args) => {
            if (args.length < 2) return "Usage: register <username> <password>";
            localStorage.setItem('tahoe_user', JSON.stringify({ user: args[0], pass: args[1] }));
            return `[SUCCESS] Account '${args[0]}' created on Tahoe-Node.`;
        },

        "login": (args) => {
            if (args.length < 2) return "Usage: login <username> <password>";
            const saved = JSON.parse(localStorage.getItem('tahoe_user'));
            if (!saved || saved.user !== args[0] || saved.pass !== args[1]) {
                return "[ERROR] Authentication failed. Access denied.";
            }
            
            let session = JSON.parse(localStorage.getItem('tahoe_session'));
            session.isLoggedIn = true;
            session.currentUser = args[0];
            localStorage.setItem('tahoe_session', JSON.stringify(session));
            
            const ip = NetworkSystem.generateIP();
            return `[OK] Welcome back, ${args[0]}.\n[OK] Network Interface Activated.\n[OK] Assigned IP: ${ip}`;
        },

        "ls": () => FileSystem.ls(),

        "cat": (args) => {
            if (!args[0]) return "cat: missing filename";
            const fs = FileSystem.getFS();
            const file = fs[`/home/root/${args[0]}`];
            return file ? file.content : `cat: ${args[0]}: No such file or directory`;
        },

        "nano": (args) => {
            if (!args[0]) return "nano: missing filename";
            const fs = FileSystem.getFS();
            const path = `/home/root/${args[0]}`;
            const content = fs[path] ? fs[path].content : "";
            openEditor(args[0], content); // ส่งต่อไปที่ os-manager
            return `[PROCESS] nano ${args[0]} launched...`;
        },

        "ifconfig": () => {
            const session = JSON.parse(localStorage.getItem('tahoe_session'));
            if (!session.isLoggedIn) return "eth0: flags=4098<BROADCAST,MULTICAST>  mtu 1500\n      status: DISCONNECTED";
            return `eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500\n      inet ${session.ip}  netmask 255.255.255.0\n      device memory 0xf7d20000-f7d3ffff`;
        },

        "whoami": () => {
            const session = JSON.parse(localStorage.getItem('tahoe_session'));
            return session.isLoggedIn ? session.currentUser : "guest_user";
        },

        "nmap": () => {
            const session = JSON.parse(localStorage.getItem('tahoe_session'));
            if (!session.isLoggedIn) return "[ERR] Root privileges required. Please login.";
            return "Starting Nmap 7.92 ( https://nmap.org ) at 2026-01-27...\n" + NetworkSystem.getScanResults();
        },

        "clear": () => "CLEAR_COMMAND"
    },
    execute(input) {
        const parts = input.trim().split(" ");
        const cmd = parts[0].toLowerCase();
        const args = parts.slice(1);
        if (cmd === "") return "";
        return this.commands[cmd] ? this.commands[cmd](args) : `bash: ${cmd}: command not found. Type 'help'.`;
    }
};